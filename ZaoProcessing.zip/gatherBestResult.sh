
th=$1
outDir=$2

python processOutputBestMatchConditional.py $th $outDir/topsRefineno100FBP75 $outDir/topsRefineno100FBP85 $outDir/topsRefineyes100FBP75 $outDir/topsRefineyes50FBP75 $outDir/topsRefineyes75FBP75 $outDir/topsRefineyes100FBP85 $outDir/topsRefineyes50FBP85 $outDir/topsRefineyes75FBP85 $outDir/topsRefineyes100FBP95 $outDir/topsRefineyes50FBP95 $outDir/topsRefineyes75FBP95 


